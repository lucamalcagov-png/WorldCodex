@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle -p "%~dp0" %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Open this project in Android Studio, or install Gradle 8.9+ and run gradlew.bat.
exit /b 1
